z <- c(54,78,56,44,88)  
png(file = "linegraph.jpg")  
plot(z,type = "o",col="red",xlab="semester",ylab="percentaile")  
dev.off()